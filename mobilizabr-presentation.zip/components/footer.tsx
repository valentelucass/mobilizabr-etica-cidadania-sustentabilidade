export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm">&copy; 2025 Ética, Cidadania e Sustentabilidade. Criado pelo grupo MobilizaBR.</p>
        </div>
      </div>
    </footer>
  )
}
